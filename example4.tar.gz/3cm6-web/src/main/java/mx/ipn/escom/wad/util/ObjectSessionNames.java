package mx.ipn.escom.wad.util;

public class ObjectSessionNames {
	public static final String PERSONA = "mx.escom.ipn.mx.persona";
}
